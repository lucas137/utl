var classutl_1_1io_1_1tcp_1_1connection =
[
    [ "read_handler", "classutl_1_1io_1_1tcp_1_1connection.html#a04afab5af264f176533b9369f30d33ca", null ],
    [ "connection", "classutl_1_1io_1_1tcp_1_1connection.html#a3d9a6b76e425ab88fe05ff427b5e8d1b", null ],
    [ "connection", "classutl_1_1io_1_1tcp_1_1connection.html#a678c01656adcaeef3dcf6b8c878805ea", null ],
    [ "is_open", "classutl_1_1io_1_1tcp_1_1connection.html#a010c8f64ba61194ca9788480e8ea98a0", null ],
    [ "start", "classutl_1_1io_1_1tcp_1_1connection.html#a7b5997697da94a37eee8366361317195", null ],
    [ "start", "classutl_1_1io_1_1tcp_1_1connection.html#a7b5997697da94a37eee8366361317195", null ],
    [ "stop", "classutl_1_1io_1_1tcp_1_1connection.html#a05367f67a5b62ba2df7793b0ce3d39f6", null ],
    [ "stop", "classutl_1_1io_1_1tcp_1_1connection.html#a05367f67a5b62ba2df7793b0ce3d39f6", null ],
    [ "write", "classutl_1_1io_1_1tcp_1_1connection.html#ac595ddedef1a1153a1a8493558553198", null ],
    [ "write", "classutl_1_1io_1_1tcp_1_1connection.html#ac595ddedef1a1153a1a8493558553198", null ]
];