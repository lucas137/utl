var highgui_8hpp =
[
    [ "mouse_event_str", "highgui_8hpp.html#gae2ff6ab9438f931d86b6139268a681c4", null ],
    [ "mouse_flags_str", "highgui_8hpp.html#ga2d61f2c933cc57e66bd5f9fd38b298cd", null ],
    [ "special_key_str", "highgui_8hpp.html#ga80c17a441f321ccc779085a35dc2a878", null ]
];