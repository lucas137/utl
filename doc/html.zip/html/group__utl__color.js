var group__utl__color =
[
    [ "color_rgb", "structutl_1_1color__rgb.html", [
      [ "blue", "structutl_1_1color__rgb.html#a89b418d21427a735c4542c1568938819", null ],
      [ "green", "structutl_1_1color__rgb.html#ab83c0f9abe3ce317fd03dff4ea6b71d2", null ],
      [ "red", "structutl_1_1color__rgb.html#a69ac9b0cc2dce7703e07813c4105b9b7", null ]
    ] ]
];