var classutl_1_1opencv_1_1_text_rect =
[
    [ "TextRect", "classutl_1_1opencv_1_1_text_rect.html#ae9cec38c7acacd304db920bdd3299f91", null ],
    [ "draw", "classutl_1_1opencv_1_1_text_rect.html#aa7ec2df8323ee5207abac80c374e5342", null ],
    [ "rect_color", "classutl_1_1opencv_1_1_text_rect.html#af1b7ba664a40ba509e30f9eef929df28", null ],
    [ "text_color", "classutl_1_1opencv_1_1_text_rect.html#a4106a64354badbb8eeeca597c9be39ac", null ],
    [ "text_str", "classutl_1_1opencv_1_1_text_rect.html#a020a93bf8659f0dcb8234a56d990c65f", null ]
];