var namespaceutl =
[
    [ "app", "namespaceutl_1_1app.html", "namespaceutl_1_1app" ],
    [ "chrono", "namespaceutl_1_1chrono.html", "namespaceutl_1_1chrono" ],
    [ "file", "namespaceutl_1_1file.html", "namespaceutl_1_1file" ],
    [ "fltk", "namespaceutl_1_1fltk.html", "namespaceutl_1_1fltk" ],
    [ "io", null, [
      [ "tcp", null, [
        [ "client", "classutl_1_1io_1_1tcp_1_1client.html", "classutl_1_1io_1_1tcp_1_1client" ],
        [ "connection", "classutl_1_1io_1_1tcp_1_1connection.html", "classutl_1_1io_1_1tcp_1_1connection" ],
        [ "connection_manager", "classutl_1_1io_1_1tcp_1_1connection__manager.html", "classutl_1_1io_1_1tcp_1_1connection__manager" ],
        [ "server", "classutl_1_1io_1_1tcp_1_1server.html", "classutl_1_1io_1_1tcp_1_1server" ]
      ] ]
    ] ],
    [ "math", "namespaceutl_1_1math.html", "namespaceutl_1_1math" ],
    [ "opencv", "namespaceutl_1_1opencv.html", "namespaceutl_1_1opencv" ],
    [ "accumulate_ostream", "classutl_1_1accumulate__ostream.html", "classutl_1_1accumulate__ostream" ],
    [ "color_rgb", "structutl_1_1color__rgb.html", "structutl_1_1color__rgb" ],
    [ "conststr", "classutl_1_1conststr.html", "classutl_1_1conststr" ],
    [ "queue", "classutl_1_1queue.html", "classutl_1_1queue" ],
    [ "Summation", "classutl_1_1_summation.html", "classutl_1_1_summation" ],
    [ "TupleString", "structutl_1_1_tuple_string.html", "structutl_1_1_tuple_string" ]
];