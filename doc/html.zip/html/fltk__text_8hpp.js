var fltk__text_8hpp =
[
    [ "AlignX", "fltk__text_8hpp.html#ga31a8c79fd8adc916443f5d66afb75711", [
      [ "LEFT", "fltk__text_8hpp.html#gga31a8c79fd8adc916443f5d66afb75711a684d325a7303f52e64011467ff5c5758", null ],
      [ "CENTER", "fltk__text_8hpp.html#gga31a8c79fd8adc916443f5d66afb75711ac397289ee45877be0cd49811fe245b4e", null ],
      [ "RIGHT", "fltk__text_8hpp.html#gga31a8c79fd8adc916443f5d66afb75711a21507b40c80068eda19865706fdc2403", null ]
    ] ],
    [ "AlignY", "fltk__text_8hpp.html#ga0bfc3fc2c209e005d7e70810b4d3a883", [
      [ "TOP", "fltk__text_8hpp.html#gga0bfc3fc2c209e005d7e70810b4d3a883a6705777b712ee811e76fb07162081d63", null ],
      [ "MIDDLE", "fltk__text_8hpp.html#gga0bfc3fc2c209e005d7e70810b4d3a883a43eedd8685eb86592022f8da962e3474", null ],
      [ "BOTTOM", "fltk__text_8hpp.html#gga0bfc3fc2c209e005d7e70810b4d3a883a1fabf63de5c96c78e2a40805bcdeb73b", null ]
    ] ]
];