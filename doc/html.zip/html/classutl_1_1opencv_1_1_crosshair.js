var classutl_1_1opencv_1_1_crosshair =
[
    [ "Crosshair", "classutl_1_1opencv_1_1_crosshair.html#a104bdb156609be2d7117409319a5ea2b", null ],
    [ "Crosshair", "classutl_1_1opencv_1_1_crosshair.html#a4877e92dad75b77f0fc3ca894ea14de2", null ],
    [ "center", "classutl_1_1opencv_1_1_crosshair.html#aac70d817aa8e52810fd29f2adc6e7a97", null ],
    [ "draw", "classutl_1_1opencv_1_1_crosshair.html#a0e207efa618d7fcc3803df2ad6852c88", null ],
    [ "is_visible", "classutl_1_1opencv_1_1_crosshair.html#acec2c719ab9c44d1c9b79230c22d9055", null ],
    [ "is_visible", "classutl_1_1opencv_1_1_crosshair.html#a132dabf2b531a9e1d116c101a9bdc651", null ]
];