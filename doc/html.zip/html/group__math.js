var group__math =
[
    [ "literals", "namespaceutl_1_1math_1_1literals.html", null ],
    [ "sample_window", "structutl_1_1math_1_1sample__window.html", [
      [ "clear", "structutl_1_1math_1_1sample__window.html#a5a09bb14fd48d54390511e3464e7abdb", null ],
      [ "empty", "structutl_1_1math_1_1sample__window.html#a4ce69acc725400a0e1d3669b5f7e7ffe", null ],
      [ "max", "structutl_1_1math_1_1sample__window.html#af6c339342db5d1d214d5b8ab93c2c046", null ],
      [ "mean", "structutl_1_1math_1_1sample__window.html#a0a3ffb4889c5488981253901d124bfbc", null ],
      [ "min", "structutl_1_1math_1_1sample__window.html#a6c9fce9d736019d36697fd806087b418", null ],
      [ "push", "structutl_1_1math_1_1sample__window.html#a5f25f59727686fd3cb1d9700f73d4fd1", null ],
      [ "size", "structutl_1_1math_1_1sample__window.html#ad540b56fd285ddd83764e36870fc1189", null ],
      [ "sum", "structutl_1_1math_1_1sample__window.html#a37362f0c4d0ee35facf0287b8521058b", null ],
      [ "window_size", "structutl_1_1math_1_1sample__window.html#a2d923b1824a691f724e87d0fa6186701", null ]
    ] ],
    [ "bound", "group__math.html#gad128584343f11946a75ef2cd3005156f", null ],
    [ "deg_to_rad", "group__math.html#gab0832bf56dc22ed62e6655ae95d8a0e7", null ],
    [ "in_radius", "group__math.html#ga9be23bb3dcb2db4e0a4ae70ccd8c27cb", null ],
    [ "rad_to_deg", "group__math.html#ga7bcbb88fb8509d07bee60958e25caaf0", null ],
    [ "squared_distance", "group__math.html#gac8caa13d30f2168978153755509e4ed7", null ],
    [ "standard_deg", "group__math.html#ga9923b1c78b9f3f4d40887f548df17ebe", null ],
    [ "standard_rad", "group__math.html#ga983a158070839d5e6f005fec0a6babbe", null ],
    [ "pi", "group__math.html#ga618935bfe80a8235835712a577bf6dd1", null ],
    [ "two_pi", "group__math.html#ga11dde1dfd10368529ac6864346cf46b3", null ]
];