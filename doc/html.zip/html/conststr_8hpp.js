var conststr_8hpp =
[
    [ "conststr", "classutl_1_1conststr.html", "classutl_1_1conststr" ],
    [ "operator<<", "conststr_8hpp.html#a57809e8be35e93dc216d888a87475b83", null ]
];