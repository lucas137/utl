var countdown_8hpp =
[
    [ "countdown_circle_flat", "countdown_8hpp.html#ga6fd8f6b4f043e7584b549cae4238a2bb", null ],
    [ "countdown_circle_round", "countdown_8hpp.html#gaf0300fa826fd0cb7a981e0a2b70be2c1", null ]
];