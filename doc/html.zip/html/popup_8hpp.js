var popup_8hpp =
[
    [ "PopupType", "popup_8hpp.html#gacc166b6a7fb55e850cb3f5bb4f07d7ca", [
      [ "error", "popup_8hpp.html#ggacc166b6a7fb55e850cb3f5bb4f07d7caacb5e100e5a9a3e7f6d1fd97512215282", null ],
      [ "message", "popup_8hpp.html#ggacc166b6a7fb55e850cb3f5bb4f07d7caa78e731027d8fd50ed642340b7c9a63b3", null ],
      [ "warning", "popup_8hpp.html#ggacc166b6a7fb55e850cb3f5bb4f07d7caa7b83d3f08fa392b79e3f553b585971cd", null ]
    ] ],
    [ "popup", "popup_8hpp.html#gaec4da15d40bfd40e06edd383d88f4e75", null ],
    [ "color_bgr", "popup_8hpp.html#a967e1c020b8b0ad3a43c7b29bfddeefd", null ],
    [ "color_bgr", "popup_8hpp.html#a0e73ab828b76af4ecd6b23b095d4b60f", null ],
    [ "error_bgr", "popup_8hpp.html#a77eda51ec679f07ef4057c806d9d8750", null ],
    [ "face", "popup_8hpp.html#a6279e889b46489a345cec3643008e471", null ],
    [ "face", "popup_8hpp.html#a849756695acd6aa275b00964006593f2", null ],
    [ "height", "popup_8hpp.html#ae8a9ad53cf884838f6105f0e809bc8a3", null ],
    [ "message_bgr", "popup_8hpp.html#abb1a3c33fb66c029277602a7abbbf7c3", null ],
    [ "scale", "popup_8hpp.html#aba5d796ffa80beb9416503216ae45fe9", null ],
    [ "scale", "popup_8hpp.html#a85fbb491813bb294fa7f1d1d35ceb5a3", null ],
    [ "thickness", "popup_8hpp.html#a61e6ecac3e2ce1fb2d05de6f00bfdd7f", null ],
    [ "thickness", "popup_8hpp.html#a5cdd6f91e28476da5f4805059879b085", null ],
    [ "warning_bgr", "popup_8hpp.html#a8d0c0bd36b3060543a8fb924580a80b8", null ],
    [ "width", "popup_8hpp.html#a3efcb9fb2f7feba551dd830de28dcdfc", null ]
];