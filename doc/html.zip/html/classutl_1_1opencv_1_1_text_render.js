var classutl_1_1opencv_1_1_text_render =
[
    [ "TextRender", "classutl_1_1opencv_1_1_text_render.html#ad19f60a6516e68e38e1efddce2729f9e", null ],
    [ "ascent_px", "classutl_1_1opencv_1_1_text_render.html#af1bbf4b6f02a18467566cc0b3fa17d8f", null ],
    [ "descent_px", "classutl_1_1opencv_1_1_text_render.html#a19183acc897cd94f8243dbe713c4a76e", null ],
    [ "draw", "classutl_1_1opencv_1_1_text_render.html#ae34bfd854e6eff5d41be6f0116ca34ef", null ],
    [ "draw", "classutl_1_1opencv_1_1_text_render.html#a785ae8ce0bd2fb215960ebf4aad4c6c3", null ],
    [ "height_px", "classutl_1_1opencv_1_1_text_render.html#a3ece25d417a75061667b61d6aa697cd7", null ],
    [ "spacing_mult", "classutl_1_1opencv_1_1_text_render.html#a358595c261a2b7034f7642fbdeb346e3", null ],
    [ "spacing_px", "classutl_1_1opencv_1_1_text_render.html#aeaf52e98a7a3f1a1a8533464f6d75e62", null ],
    [ "width_px", "classutl_1_1opencv_1_1_text_render.html#ab55d6ce77a908fb642b8bc73e7ca1ba0", null ],
    [ "width_px", "classutl_1_1opencv_1_1_text_render.html#ab9e318fee30f36550c0c845f2eaaa0ec", null ]
];