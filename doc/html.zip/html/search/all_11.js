var searchData=
[
  ['rad_5fto_5fdeg',['rad_to_deg',['../group__math.html#ga7bcbb88fb8509d07bee60958e25caaf0',1,'utl::math']]],
  ['radius_5fpx',['radius_px',['../classutl_1_1fltk_1_1_circle.html#a096286d1f3aa2fb77f4b7fdd67f7f91a',1,'utl::fltk::Circle::radius_px() const '],['../classutl_1_1fltk_1_1_circle.html#a7098148941716dd100fb73a9bd917fed',1,'utl::fltk::Circle::radius_px(unsigned r_px)']]],
  ['randomize',['randomize',['../namespaceutl.html#ad1ce9f90a8fd00afbf764de95b5e7545',1,'utl']]],
  ['randomize_2ehpp',['randomize.hpp',['../randomize_8hpp.html',1,'']]],
  ['rect',['rect',['../classutl_1_1opencv_1_1_panel.html#a568ba1b26c681d922013a3a6dbd34dea',1,'utl::opencv::Panel::rect()'],['../classutl_1_1opencv_1_1_text_panel.html#abdd68cc794ddbce6413be82da86e7ff7',1,'utl::opencv::TextPanel::rect()'],['../classutl_1_1opencv_1_1_key_panel.html#a5af5ed6254180d147e33ce23e0d33268',1,'utl::opencv::KeyPanel::rect()']]],
  ['rect_5fcolor',['rect_color',['../classutl_1_1opencv_1_1_text_rect.html#af1b7ba664a40ba509e30f9eef929df28',1,'utl::opencv::TextRect']]],
  ['rectangle_2ehpp',['rectangle.hpp',['../rectangle_8hpp.html',1,'']]],
  ['rectangle_5f',['Rectangle_',['../classutl_1_1opencv_1_1_rectangle__.html#a56bc4834a9bd27325871355371d458e6',1,'utl::opencv::Rectangle_::Rectangle_(T x, T y, T width, T height, bool visible, cv::Scalar const &amp;color_bgr, int thickness=1, int line_type=cv::LINE_8, int shift=0)'],['../classutl_1_1opencv_1_1_rectangle__.html#ae1ea80b6ebe9dfe41d2902495090c33a',1,'utl::opencv::Rectangle_::Rectangle_(cv::Point_&lt; T &gt; const &amp;pt1, cv::Point_&lt; T &gt; const &amp;pt2, bool visible, cv::Scalar const &amp;color_bgr, int thickness=1, int line_type=cv::LINE_8, int shift=0)'],['../classutl_1_1opencv_1_1_rectangle__.html#a35fb7e287118e5ed66f117ef1005566e',1,'utl::opencv::Rectangle_::Rectangle_(cv::Scalar const &amp;color_bgr, int thickness=1, int line_type=cv::LINE_8, int shift=0)'],['../classutl_1_1opencv_1_1_rectangle__.html#ab9d5c55128e06e1314460297e6cc1c60',1,'utl::opencv::Rectangle_::Rectangle_()=default']]],
  ['rectangle_5f',['Rectangle_',['../classutl_1_1opencv_1_1_rectangle__.html',1,'utl::opencv']]],
  ['red',['red',['../structutl_1_1color__rgb.html#a69ac9b0cc2dce7703e07813c4105b9b7',1,'utl::color_rgb::red()'],['../structutl_1_1fltk_1_1_color.html#a714f3f96f3ef8bfb1241911af7bf4fbc',1,'utl::fltk::Color::red()']]],
  ['remove_5fextension',['remove_extension',['../group__utl__file__name.html#ga0aca15c54b73cc0a55d846111b6c1a95',1,'utl::file']]],
  ['replace',['replace',['../group__string.html#gaefef910d6b9f4e3be3f065a860ee43d9',1,'utl']]],
  ['reset',['reset',['../classutl_1_1chrono_1_1timer.html#a40e90471252e5115693cc0d8bab9b315',1,'utl::chrono::timer']]],
  ['right',['RIGHT',['../group__utl__fltk.html#gga31a8c79fd8adc916443f5d66afb75711a21507b40c80068eda19865706fdc2403',1,'utl::fltk']]],
  ['rotate_5f90_5fdeg',['rotate_90_deg',['../group__utl__opencv.html#gaaa13c7d0f516371c0be73e89bb62f4da',1,'utl::opencv']]],
  ['rotated_5frect_2ehpp',['rotated_rect.hpp',['../rotated__rect_8hpp.html',1,'']]],
  ['rotatedrect',['rotatedRect',['../group__utl__opencv.html#ga2f79a780cc576216788d306f8d64d35e',1,'utl::opencv']]],
  ['rotation',['rotation',['../structutl_1_1opencv_1_1_triangle.html#aa9d4ef507d4890c39f88877e57ece643',1,'utl::opencv::Triangle']]],
  ['rs',['RS',['../group__string.html#gga827352fa2a26fb4afef66027feb2f1b6a8cee5050eeb7c783e8bfaa73003ced3a',1,'utl::ascii']]],
  ['run',['run',['../classutl_1_1io_1_1tcp_1_1client.html#a7d592e6a5b80cc0df4e764821251d0fd',1,'utl::io::tcp::client::run()'],['../classutl_1_1io_1_1tcp_1_1server.html#af5de7909c16cf57601d1ea21f44e48ce',1,'utl::io::tcp::server::run()'],['../classutl_1_1io_1_1tcp_1_1client.html#a7d592e6a5b80cc0df4e764821251d0fd',1,'utl::io::tcp::client::run()'],['../classutl_1_1io_1_1tcp_1_1server.html#af5de7909c16cf57601d1ea21f44e48ce',1,'utl::io::tcp::server::run()']]]
];
