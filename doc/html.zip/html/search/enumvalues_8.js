var searchData=
[
  ['left',['LEFT',['../group__utl__fltk.html#gga31a8c79fd8adc916443f5d66afb75711a684d325a7303f52e64011467ff5c5758',1,'utl::fltk']]],
  ['lf',['LF',['../group__string.html#gga827352fa2a26fb4afef66027feb2f1b6a618441d41cce47dbcfd9bed6e5ff64e6',1,'utl::ascii']]]
];
