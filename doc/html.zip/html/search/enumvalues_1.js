var searchData=
[
  ['bel',['BEL',['../group__string.html#gga827352fa2a26fb4afef66027feb2f1b6a6b3c549d3d068b03da16a480f8818703',1,'utl::ascii']]],
  ['bottom',['BOTTOM',['../group__utl__fltk.html#gga0bfc3fc2c209e005d7e70810b4d3a883a1fabf63de5c96c78e2a40805bcdeb73b',1,'utl::fltk']]],
  ['bs',['BS',['../group__string.html#gga827352fa2a26fb4afef66027feb2f1b6a9a231c14a3416b1055b8ffb960151aee',1,'utl::ascii']]]
];
