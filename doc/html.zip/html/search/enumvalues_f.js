var searchData=
[
  ['vt',['VT',['../group__string.html#gga827352fa2a26fb4afef66027feb2f1b6a072bfacf555fde9accd162a180ff0ac4',1,'utl::ascii']]]
];
