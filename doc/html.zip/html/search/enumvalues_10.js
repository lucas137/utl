var searchData=
[
  ['warning',['warning',['../group__utl__opencv.html#ggacc166b6a7fb55e850cb3f5bb4f07d7caa7b83d3f08fa392b79e3f553b585971cd',1,'utl::opencv']]]
];
