var searchData=
[
  ['popuptype',['PopupType',['../group__utl__opencv.html#gacc166b6a7fb55e850cb3f5bb4f07d7ca',1,'utl::opencv']]]
];
