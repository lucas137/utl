var classutl_1_1opencv_1_1_text_panel =
[
    [ "TextPanel", "classutl_1_1opencv_1_1_text_panel.html#ade4f60d8ca52d93d15cec61d8504aa6a", null ],
    [ "body", "classutl_1_1opencv_1_1_text_panel.html#a91198c1dc9cc40d12ddfc4c03ae510fb", null ],
    [ "center", "classutl_1_1opencv_1_1_text_panel.html#aa34532d499bdc49d59a46d8c7775ed9f", null ],
    [ "center", "classutl_1_1opencv_1_1_text_panel.html#a2922092e1e2d17f2b47726d3ea932aae", null ],
    [ "draw", "classutl_1_1opencv_1_1_text_panel.html#a731071b0fefda2d7589cbb867c17f80b", null ],
    [ "rect", "classutl_1_1opencv_1_1_text_panel.html#abdd68cc794ddbce6413be82da86e7ff7", null ],
    [ "shrink_height", "classutl_1_1opencv_1_1_text_panel.html#ac0ba00b6e58dc627e597753f9d71a5de", null ],
    [ "shrink_width", "classutl_1_1opencv_1_1_text_panel.html#a8257a3d2c06fa0402d383980c565b4e7", null ],
    [ "size", "classutl_1_1opencv_1_1_text_panel.html#af687455e0c5c545a4f2756c4febd6d15", null ],
    [ "text", "classutl_1_1opencv_1_1_text_panel.html#a323761ef08b95cf126b1875d6cbf3958", null ],
    [ "text", "classutl_1_1opencv_1_1_text_panel.html#a6f90c09004c9d46b47971872c37512a0", null ],
    [ "text_origin", "classutl_1_1opencv_1_1_text_panel.html#a323996eff917f82da1dbc7c39891ba40", null ],
    [ "text_origin", "classutl_1_1opencv_1_1_text_panel.html#a3a3cb6e5fa39ae07a88c0ac0d95c6f04", null ],
    [ "title", "classutl_1_1opencv_1_1_text_panel.html#a6dbf2ac42ef83d360b9e62037b99ca42", null ],
    [ "topleft", "classutl_1_1opencv_1_1_text_panel.html#ab5444e049cd1c1c58a3d78063b1b2e84", null ]
];