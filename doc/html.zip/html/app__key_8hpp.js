var app__key_8hpp =
[
    [ "getch", "app__key_8hpp.html#a160f6d2893bb6b89ab3ad5d863c20e3d", null ],
    [ "kbhit", "app__key_8hpp.html#ad5451da499ab9d3907da8dd7060ab677", null ],
    [ "key", "app__key_8hpp.html#ga53323aefc15146cd5a09ed3fa2ae7cbc", null ],
    [ "key_wait", "app__key_8hpp.html#ga25985535c4083f5a56ed1f064fb3fd11", null ],
    [ "key_wait", "app__key_8hpp.html#ga30777bdac103121213dd5804b8d5a35a", null ]
];