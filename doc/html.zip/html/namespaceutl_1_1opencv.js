var namespaceutl_1_1opencv =
[
    [ "CircleRegion", "classutl_1_1opencv_1_1_circle_region.html", "classutl_1_1opencv_1_1_circle_region" ],
    [ "Coordinates", "classutl_1_1opencv_1_1_coordinates.html", "classutl_1_1opencv_1_1_coordinates" ],
    [ "Crosshair", "classutl_1_1opencv_1_1_crosshair.html", "classutl_1_1opencv_1_1_crosshair" ],
    [ "KeyPanel", "classutl_1_1opencv_1_1_key_panel.html", "classutl_1_1opencv_1_1_key_panel" ],
    [ "Panel", "classutl_1_1opencv_1_1_panel.html", "classutl_1_1opencv_1_1_panel" ],
    [ "Rectangle_", "classutl_1_1opencv_1_1_rectangle__.html", "classutl_1_1opencv_1_1_rectangle__" ],
    [ "special_key", "structutl_1_1opencv_1_1special__key.html", null ],
    [ "TextPanel", "classutl_1_1opencv_1_1_text_panel.html", "classutl_1_1opencv_1_1_text_panel" ],
    [ "TextRect", "classutl_1_1opencv_1_1_text_rect.html", "classutl_1_1opencv_1_1_text_rect" ],
    [ "TextRender", "classutl_1_1opencv_1_1_text_render.html", "classutl_1_1opencv_1_1_text_render" ],
    [ "Triangle", "structutl_1_1opencv_1_1_triangle.html", "structutl_1_1opencv_1_1_triangle" ]
];