var math_8hpp =
[
    [ "bound", "math_8hpp.html#gad128584343f11946a75ef2cd3005156f", null ],
    [ "deg_to_rad", "math_8hpp.html#gab0832bf56dc22ed62e6655ae95d8a0e7", null ],
    [ "in_radius", "math_8hpp.html#ga9be23bb3dcb2db4e0a4ae70ccd8c27cb", null ],
    [ "operator\"\"_deg", "math_8hpp.html#a169793fc311b9d0cb143efdd32948cdc", null ],
    [ "operator\"\"_deg", "math_8hpp.html#af81231e4aa9eafaa36ecbdde060753f4", null ],
    [ "operator\"\"_rad", "math_8hpp.html#a9694a4af10b529f3a7962528755a0ccf", null ],
    [ "operator\"\"_rad2deg", "math_8hpp.html#a7362d7d23f59a2540d5ddc7db2f21da1", null ],
    [ "rad_to_deg", "math_8hpp.html#ga7bcbb88fb8509d07bee60958e25caaf0", null ],
    [ "squared_distance", "math_8hpp.html#gac8caa13d30f2168978153755509e4ed7", null ],
    [ "standard_deg", "math_8hpp.html#ga9923b1c78b9f3f4d40887f548df17ebe", null ],
    [ "standard_rad", "math_8hpp.html#ga983a158070839d5e6f005fec0a6babbe", null ],
    [ "pi", "math_8hpp.html#ga618935bfe80a8235835712a577bf6dd1", null ],
    [ "two_pi", "math_8hpp.html#ga11dde1dfd10368529ac6864346cf46b3", null ]
];