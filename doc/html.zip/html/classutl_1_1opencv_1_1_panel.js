var classutl_1_1opencv_1_1_panel =
[
    [ "Panel", "classutl_1_1opencv_1_1_panel.html#a496008a9d8f0a2bd05ed2406d02f64c9", null ],
    [ "body", "classutl_1_1opencv_1_1_panel.html#a0ee963f844cc953d1131e08f6e57118c", null ],
    [ "center", "classutl_1_1opencv_1_1_panel.html#a53cef987e8d20336b2e1767b566acc5f", null ],
    [ "center", "classutl_1_1opencv_1_1_panel.html#a724c73945f28f7595af48515eff531e8", null ],
    [ "draw", "classutl_1_1opencv_1_1_panel.html#a84d579275da4ae962c8ef244f8c8750c", null ],
    [ "rect", "classutl_1_1opencv_1_1_panel.html#a568ba1b26c681d922013a3a6dbd34dea", null ],
    [ "shrink_height", "classutl_1_1opencv_1_1_panel.html#af7842451c98c3c75926bedb61bcabc15", null ],
    [ "shrink_width", "classutl_1_1opencv_1_1_panel.html#a1e1ffc9fac74f717bbbe29422cd08416", null ],
    [ "size", "classutl_1_1opencv_1_1_panel.html#ae37892ac3244bbfbbdd3d7983ef9a66f", null ],
    [ "title", "classutl_1_1opencv_1_1_panel.html#ae0c7bb342b7019aed656be6ae97d1c95", null ],
    [ "topleft", "classutl_1_1opencv_1_1_panel.html#aedd7dc4e1d86a9133a13c8bcbd5e83bd", null ]
];