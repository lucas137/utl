var classutl_1_1opencv_1_1_circle_region =
[
    [ "CircleRegion", "classutl_1_1opencv_1_1_circle_region.html#ac6ccde374be8cd9812ef4ee0d0b8b07f", null ],
    [ "active", "classutl_1_1opencv_1_1_circle_region.html#aa8db4cd5e103c9104978b496ed881a23", null ],
    [ "center", "classutl_1_1opencv_1_1_circle_region.html#ac391cf97640606cd0e8b490fca7bc11f", null ],
    [ "center", "classutl_1_1opencv_1_1_circle_region.html#a0074ae48f2077a0a2add414f8a121add", null ],
    [ "contains", "classutl_1_1opencv_1_1_circle_region.html#a8ffb131d84d6590b4115fc0866fe2de0", null ],
    [ "draw", "classutl_1_1opencv_1_1_circle_region.html#a3b77e94bd881b865a9881437f0b66d6c", null ],
    [ "draw_active", "classutl_1_1opencv_1_1_circle_region.html#af040b6cc5c8e730ac24f23b526e93299", null ],
    [ "is_active", "classutl_1_1opencv_1_1_circle_region.html#a9cf85732225c3320161d9be6d1307d15", null ],
    [ "is_active", "classutl_1_1opencv_1_1_circle_region.html#a8eed80498ba908ede307eb4635f08af5", null ]
];