var iostream_8hpp =
[
    [ "cout_coord", "iostream_8hpp.html#ga1e2ef07a10313e6fcc37bd12f86ecc6e", null ],
    [ "cout_coord", "iostream_8hpp.html#gacc48afa06d2d1a0b7ac2db19b1424ca8", null ],
    [ "cout_hex", "iostream_8hpp.html#ga39539ecb3a1022f3f8e4ec65c6adcf26", null ],
    [ "cout_value", "iostream_8hpp.html#gab470c250d3f3257f35d9a974430afa4f", null ],
    [ "cout_value", "iostream_8hpp.html#ga3e6cfcd7122b48b976027f41025979f1", null ]
];