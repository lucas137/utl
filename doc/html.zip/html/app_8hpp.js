var app_8hpp =
[
    [ "Arguments", "app_8hpp.html#ga8f6d0bf159b1378573dd5e58dbe79af2", null ],
    [ "parse_args", "app_8hpp.html#ga0fcbb818bcb00beb3df795d5343b76aa", null ]
];