var rotated__rect_8hpp =
[
    [ "CV_FILLED", "rotated__rect_8hpp.html#a0bbcfe5cf6dfb89747c48d124da67c64", null ],
    [ "rotatedRect", "rotated__rect_8hpp.html#ga2f79a780cc576216788d306f8d64d35e", null ]
];