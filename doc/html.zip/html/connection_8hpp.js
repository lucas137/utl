var connection_8hpp =
[
    [ "connection_ptr", "connection_8hpp.html#gaf935f0e236ea25bae7e1c8a6e9eb167c", null ]
];