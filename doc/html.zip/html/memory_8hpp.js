var memory_8hpp =
[
    [ "make_unique", "memory_8hpp.html#aa0b5dfcfeebe4c80841aef86ff6f2ce4", null ]
];