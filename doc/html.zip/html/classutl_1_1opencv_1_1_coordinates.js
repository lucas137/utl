var classutl_1_1opencv_1_1_coordinates =
[
    [ "Coordinates", "classutl_1_1opencv_1_1_coordinates.html#aff128f180ed78c384f92b48c30677159", null ],
    [ "draw", "classutl_1_1opencv_1_1_coordinates.html#a57a0d6ea5cdc19d99abf10ae7a2f46d1", null ],
    [ "point", "classutl_1_1opencv_1_1_coordinates.html#a23bde5eb5194fc59054a610e98bba262", null ],
    [ "point", "classutl_1_1opencv_1_1_coordinates.html#a393064c1b4812d81d14b2de4564ada64", null ]
];